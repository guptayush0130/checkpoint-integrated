import fs from 'node:fs/promises';
import path from 'node:path';
import { MockDatabase } from './database';
import { AuthHandler } from './auth';
import { StorageHandler } from './storage';
import { MockSupabaseServer } from './server';

export interface SchemaInput {
  /** Path to a SQL file with DDL + optional seed data. */
  file?: string;
  /** Inline SQL string (DDL + optional seed data). */
  sql?: string;
}

export interface SeedInput {
  file?: string;
  sql?: string;
}

export interface StorageBucketSeed {
  name: string;
  public?: boolean;
  files?: Array<{ path: string; body: string | Buffer; contentType?: string }>;
}

export interface MockSupabaseInstanceOptions {
  /** SQL DDL/DML applied once on `setup()`. */
  schema?: SchemaInput | SchemaInput[];
  /** SQL DML applied after schema and on every `reset()`. */
  seed?: SeedInput | SeedInput[];
  /** Storage buckets/files to provision and re-create on `reset()`. */
  storage?: StorageBucketSeed[];
  /** HTTP port (0 = random open port). */
  port?: number;
  /** Hostname (default 127.0.0.1). */
  host?: string;
  /** Tables that should be the canonical "snapshot" target for evaluation. */
  snapshotTables?: string[];
  /** Optional human label. */
  name?: string;
}

export interface RuntimeEnv {
  SUPABASE_URL: string;
  SUPABASE_ANON_KEY: string;
  SUPABASE_SERVICE_ROLE_KEY: string;
}

/**
 * Top-level lifecycle for a mock Supabase. Spin up, load schema, snapshot,
 * reset between tests, tear down. All in-process — no Docker.
 */
export class MockSupabaseInstance {
  readonly db: MockDatabase;
  readonly auth: AuthHandler;
  readonly storage: StorageHandler;
  readonly server: MockSupabaseServer;
  private schemaSqls: string[] = [];
  private seedSqls: string[] = [];
  private storageSeeds: StorageBucketSeed[];
  private port?: number;
  private host?: string;
  private url: string | null = null;
  private snapshotTables: string[];
  private started = false;

  constructor(private opts: MockSupabaseInstanceOptions = {}) {
    this.db = new MockDatabase();
    this.auth = new AuthHandler(opts.name || 'default');
    this.storage = new StorageHandler();
    this.server = new MockSupabaseServer(this.db, this.auth, this.storage);
    this.storageSeeds = opts.storage || [];
    this.port = opts.port;
    this.host = opts.host;
    this.snapshotTables = opts.snapshotTables || [];
  }

  /** Start the HTTP server, apply schema + seed + storage. Idempotent. */
  async setup(): Promise<RuntimeEnv> {
    if (this.started) {
      return this.runtimeEnv();
    }
    this.url = await this.server.start({ port: this.port, host: this.host });
    await this.db.waitReady();

    this.schemaSqls = await loadSqlInputs(this.opts.schema);
    this.seedSqls = await loadSqlInputs(this.opts.seed);

    for (const sql of this.schemaSqls) {
      if (sql.trim()) await this.db.exec(sql);
    }
    for (const sql of this.seedSqls) {
      if (sql.trim()) await this.db.exec(sql);
    }
    this.applyStorageSeeds();

    this.started = true;
    return this.runtimeEnv();
  }

  /** Wipe all DB data, re-apply seeds and storage. Schema (DDL) is kept. */
  async reset(): Promise<void> {
    if (!this.started) {
      await this.setup();
      return;
    }
    const tables = await this.db.listTables();
    if (tables.length) {
      await this.db.resetData(tables);
    }
    for (const sql of this.seedSqls) {
      if (sql.trim()) await this.db.exec(sql);
    }
    this.storage.reset();
    this.applyStorageSeeds();
  }

  /** Drop all tables and shut down. */
  async teardown(): Promise<void> {
    try {
      await this.db.dropAll();
    } catch {
      // best-effort
    }
    await this.server.stop();
    await this.db.close();
    this.started = false;
    this.url = null;
  }

  /** Capture the contents of all (or selected) tables. */
  async snapshot(tables?: string[]): Promise<Record<string, any[]>> {
    const list = tables && tables.length ? tables : await this.resolveSnapshotTables();
    return this.db.snapshot(list);
  }

  /** Compute a structural diff between two snapshots. */
  diff(before: Record<string, any[]>, after: Record<string, any[]>) {
    const result: Record<string, { added: any[]; removed: any[]; changed: any[] }> = {};
    for (const table of Object.keys({ ...before, ...after })) {
      const a = before[table] || [];
      const b = after[table] || [];
      const haveIds = [...a, ...b].every((row) => row && Object.prototype.hasOwnProperty.call(row, 'id'));
      if (!haveIds) {
        const aSet = new Map(a.map((r) => [JSON.stringify(r), r]));
        const bSet = new Map(b.map((r) => [JSON.stringify(r), r]));
        result[table] = {
          added: b.filter((r) => !aSet.has(JSON.stringify(r))),
          removed: a.filter((r) => !bSet.has(JSON.stringify(r))),
          changed: []
        };
        continue;
      }
      const aById = new Map(a.map((row) => [String(row.id), row]));
      const bById = new Map(b.map((row) => [String(row.id), row]));
      const added = b.filter((row) => !aById.has(String(row.id)));
      const removed = a.filter((row) => !bById.has(String(row.id)));
      const changed = b
        .filter((row) => aById.has(String(row.id)))
        .map((row) => ({ before: aById.get(String(row.id)), after: row }))
        .filter((pair) => JSON.stringify(pair.before) !== JSON.stringify(pair.after));
      result[table] = { added, removed, changed };
    }
    return result;
  }

  async resolveSnapshotTables(): Promise<string[]> {
    if (this.snapshotTables.length) return this.snapshotTables;
    return this.db.listTables();
  }

  runtimeEnv(): RuntimeEnv {
    if (!this.url) throw new Error('Instance not started');
    return {
      SUPABASE_URL: this.url,
      SUPABASE_ANON_KEY: this.auth.anonKey,
      SUPABASE_SERVICE_ROLE_KEY: this.auth.serviceRoleKey
    };
  }

  private applyStorageSeeds() {
    for (const bucket of this.storageSeeds) {
      this.storage.ensureBucket(bucket.name, bucket.public);
      for (const file of bucket.files || []) {
        this.storage.handle({
          method: 'POST',
          path: `object/${bucket.name}/${file.path}`,
          headers: { 'content-type': file.contentType || 'application/octet-stream' },
          body: typeof file.body === 'string' ? Buffer.from(file.body) : file.body,
          query: new URLSearchParams()
        });
      }
    }
  }
}

async function loadSqlInputs(input?: SchemaInput | SchemaInput[]): Promise<string[]> {
  if (!input) return [];
  const list = Array.isArray(input) ? input : [input];
  const out: string[] = [];
  for (const item of list) {
    if (item.sql) out.push(item.sql);
    if (item.file) {
      const resolved = path.resolve(item.file);
      const sql = await fs.readFile(resolved, 'utf8');
      out.push(sql);
    }
  }
  return out;
}
